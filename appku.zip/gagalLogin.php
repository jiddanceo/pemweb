<div class="jumbotron">
  <h1 class="display-4">Gagal Login</h1>
  <hr class="my-4">
  <p>Maaf User/Pasword Anda Salah!!!</p>
  <a class="btn btn-primary btn-lg" href="index.php?hal=formLogin" role="button">Login</a>
</div>