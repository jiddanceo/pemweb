<div class="row" >
  <div class="col-md-9" >
    <div class="jumbotron" style="background-color: rgb(241 163 73);">
      <h1 class="display-4">Selamat Datang di Dpedia</h1>
      <p class="lead">Situs Website Pulsa Online</p>
      <hr class="my-4">
      <p>Selamat Berkunjung</p>
      <a class="btn btn-primary btn-lg" href="#" role="button">Lebih Lanjut</a>
  </div>
</div>

<div class="col-md-3">
  <ul class="list-group">
    <li class="list-group-item active" aria-current="true">Produk</li>
    <li class="list-group-item">Pulsa</li>
    <li class="list-group-item">Kuota</li>
    <li class="list-group-item">Voucher</li>
    <li class="list-group-item">Token PLN</li>
  </ul>
</div>
</div>