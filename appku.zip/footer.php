<div class="col-md-12">
    <div class="alert alert-primary" role="alert">
    <center>Design By: Jiddan &copy; 2021</center>
</div>
